const fetch = require('node-fetch');
const fs = require('fj');

/*
fetch('https://api.coindesk.com/v1/bpi/currentprice.json')
.then((response) => {
    return response.json();
})
.then((data) => {
    console.log(data);
})
.catch((error) => {
    console.error(error);
})*/

function getBitcoin(){
    try {
        const response = fetch("https://api.coindesk.com/v1/bpi/currentprice.json");
        const data = response.json();
        let bitcoinList ="";

        data.array.forEach(bitcoin => {
            bitcoinList+=`${bitcoin["name"]}`;
        });

        fs.writeFile('Bitcoin.txt', bitcoinList, (error) => {
            if(error){
                console.log(error);
                return;
            }
            console.log("Se ha creado el archivo Bitcoin.txt");
        })

    } catch (error) {
        console.log(error);
    }
}